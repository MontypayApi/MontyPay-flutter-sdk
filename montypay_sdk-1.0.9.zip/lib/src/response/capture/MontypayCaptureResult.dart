
import 'package:montypay_sdk/montypay_sdk.dart';

class MontypayCaptureResult{
  MontypayCaptureSuccess? success;
  MontypayCaptureDecline? decline;
  MontypayError? error;
  dynamic failure;
  Map? responseJSON;

  MontypayCaptureResult(Map result){
    if(result.containsKey("success")) {
      success = MontypayCaptureSuccess.fromJson(result["success"]);
    }
    if(result.containsKey("decline")) {
      decline = MontypayCaptureDecline.fromJson(result["decline"]);
    }
    if(result.containsKey("error")) {
      error = MontypayError.fromJson(result["error"]);
    }
    if(result.containsKey("failure")) {
      failure = result["failure"];
    }
    if(result.containsKey("responseJSON")) {
      responseJSON = result["responseJSON"];
    }
  }

  triggerCallbacks(CaptureResponseCallback? callback, {Function(dynamic)? onFailure, Function(Map)? onResponseJSON}){
    if(success != null) {
      callback?.success(success!);
    }

    if(decline != null) {
      callback?.decline(decline!);
    }

    if(error != null) {
      callback?.error(error!);
    }

    if(failure != null && onFailure != null) {
      onFailure(failure);
    }

    if(responseJSON != null && onResponseJSON != null) {
      onResponseJSON(responseJSON ?? {});
    }
  }
}
