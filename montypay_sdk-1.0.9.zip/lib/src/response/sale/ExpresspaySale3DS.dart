import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IDetailsMontypayResult.dart';
import 'package:montypay_sdk/src/response/sale/MontypaySale3dsRedirectParams.dart';

class MontypaySale3DS extends IDetailsMontypayResult{
  String? redirectUrl;
  String? redirectMethod;
  MontypaySale3dsRedirectParams? redirectParams;

  MontypaySale3DS.fromJson(dynamic json) : super.fromJson(json) {
    redirectUrl = json['redirect_url'];
    redirectParams = MontypaySale3dsRedirectParams.fromJson(json['redirect_params']);
    redirectMethod = json['redirect_method'];
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['redirect_url'] = redirectUrl;
    map['redirect_params'] = redirectParams;
    map['redirect_method'] = redirectMethod;
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }

}
