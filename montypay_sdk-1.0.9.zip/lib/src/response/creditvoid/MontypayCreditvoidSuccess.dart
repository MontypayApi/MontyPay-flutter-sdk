import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IMontypayResult.dart';
class MontypayCreditVoidSuccess extends IMontypayResult{

  MontypayCreditVoidSuccess.fromJson(dynamic json) : super.fromJson(json);


  @override
  String toString() {
    return jsonEncode(toJson());
  }
}