
import 'package:montypay_sdk/montypay_sdk.dart';

class MontypayCreditVoidResult{
  MontypayCreditVoidSuccess? success;
  MontypayError? error;
  dynamic failure;
  Map? responseJSON;

  MontypayCreditVoidResult(Map result){
    if(result.containsKey("success")) {
      success = MontypayCreditVoidSuccess.fromJson(result["success"]);
    }

    if(result.containsKey("error")) {
      error = MontypayError.fromJson(result["error"]);
    }

    if(result.containsKey("failure")) {
      failure = result["failure"];
    }

    if(result.containsKey("responseJSON")) {
      responseJSON = result["responseJSON"];
    }
  }

  triggerCallbacks(CreditVoidResponseCallback? callback, {Function(dynamic)? onFailure, Function(Map)? onResponseJSON}){
    if(success != null) {
      callback?.success(success!);
    }

    if(error != null) {
      callback?.error(error!);
    }

    if(failure != null && onFailure != null) {
      onFailure(failure);
    }

    if(responseJSON != null && onResponseJSON != null) {
      onResponseJSON(responseJSON ?? {});
    }
  }
}
