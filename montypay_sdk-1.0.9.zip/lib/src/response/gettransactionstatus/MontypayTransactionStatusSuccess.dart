import 'dart:convert';

import 'package:montypay_sdk/src/response/base/result/IMontypayResult.dart';

class MontypayTransactionStatusSuccess extends IMontypayResult{
  MontypayTransactionStatusSuccess.fromJson(dynamic json) : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}