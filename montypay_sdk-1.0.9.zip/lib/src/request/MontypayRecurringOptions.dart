import 'dart:convert';

class MontypayRecurringOptions {

  String? firstTransactionId;
  String? token;

  MontypayRecurringOptions({
    required this.firstTransactionId,
    required this.token
  });

  MontypayRecurringOptions.fromJson(dynamic json) {
    firstTransactionId = json['firstTransactionId'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['firstTransactionId'] = firstTransactionId;
    map['token'] = token;
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }

}