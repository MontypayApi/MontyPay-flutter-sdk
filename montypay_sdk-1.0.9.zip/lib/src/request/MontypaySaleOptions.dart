import 'dart:convert';

class MontypaySaleOption {
  String? channelId;
  bool? recurringInit;

  MontypaySaleOption({
    required this.channelId,
    required this.recurringInit
  });

  MontypaySaleOption.fromJson(dynamic json) {
    channelId = json['channelId'];
    recurringInit = json['recurringInit'];
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['channelId'] = channelId;
    map['recurringInit'] = recurringInit;
    return map;
  }


  @override
  String toString() {
    return jsonEncode(toJson());
  }
}