/*
 * Property of Montypay (https://montypay.sa).
 */


/// "Y" or "N" value holder.
///
/// @property option the option value.
enum MontypayOption{
    /// "Y" value.
    YES("Y"),

    /// "N" value.
    NO("N");

    final String option;
    const MontypayOption(this.option);


    factory MontypayOption.of(String? id) {
        return values.firstWhere((e) => e.option == id);
    }
}
