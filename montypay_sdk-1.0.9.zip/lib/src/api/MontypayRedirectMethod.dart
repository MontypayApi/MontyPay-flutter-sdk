/*
 * Property of Montypay (https://montypay.sa).
 */

/// The method of transferring parameters (POST/GET).
/// @see com.montypay.sdk.model.response.sale.MontypaySale3Ds
///
/// @property redirectMethod the redirect method value.
enum MontypayRedirectMethod{
    /// GET redirect method value.
    GET("GET"),

    /// POST redirect method value.
    POST("POST");

    final String redirectMethod;
    const MontypayRedirectMethod(this.redirectMethod);


    factory MontypayRedirectMethod.of(String? id) {
        return values.firstWhere((e) => e.redirectMethod == id);
    }
}
