/*
 * Property of Montypay (https://montypay.sa).
 */


/// The transaction type types.
/// @see com.montypay.sdk.model.response.gettransactiondetails.MontypayTransaction
///
/// @property transactionType the transaction type value.
enum MontypayTransactionType{
    /// 3DS transaction type.
    SECURE_3D("3DS"),

    /// SALE transaction type.
    SALE("SALE"),

    /// AUTH transaction type.
    AUTH("AUTH"),

    /// CAPTURE transaction type.
    CAPTURE("CAPTURE"),

    /// REVERSAL transaction type.
    REVERSAL("REVERSAL"),

    /// REFUND transaction type.
    REFUND("REFUND"),

    /// REDIRECT transaction type.
    REDIRECT("REDIRECT"),

    /// CHARGEBACK transaction type.
    CHARGEBACK("CHARGEBACK");

    final String transactionType;
    const MontypayTransactionType(this.transactionType);

    factory MontypayTransactionType.of(String? id) {
        return values.firstWhere((e) => e.transactionType == id);
    }
}
