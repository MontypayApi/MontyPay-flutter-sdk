
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';

class MontyCardPayResult{
  MontypayTransactionDetailsSuccess? success;
  MontypayTransactionDetailsSuccess? failure;
  MontypayError? error;

  MontyCardPayResult(Map result){
    if(result.containsKey("success")) {
      success = MontypayTransactionDetailsSuccess.fromJson(result["success"]);
    }
    if(result.containsKey("failure")) {
      failure = MontypayTransactionDetailsSuccess.fromJson(result["failure"]);
    }

    if(result.containsKey("error")) {
      error = MontypayError.fromJson(result["error"]);
    }
  }

  triggerCallbacks(CardPayResponseCallback? callback, {Function(dynamic)? onFailure}){
    if(success != null) {
      callback?.success(success!);
    }

    if(failure != null) {
      callback?.failure(failure!);
    }

    if(error != null) {
      callback?.error(error!);
    }
  }
}
