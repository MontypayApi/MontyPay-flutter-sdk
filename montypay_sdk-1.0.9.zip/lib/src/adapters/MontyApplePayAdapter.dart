
import 'dart:convert';

import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/Helpers.dart';
import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';
import 'package:montypay_sdk/src/applepay/MontyApplePayResult.dart';

import 'callbacks/ApplePayResponseCallback.dart';

class MontyApplePayAdapter extends BaseAdapter{

  execute({
    required String applePayMerchantId,
    required MontypaySaleOrder order,
    required MontypayPayer payer,
    required ApplePayResponseCallback? callback,
    Function(dynamic)? onFailure,
  }) {
    final params = {
      order.runtimeType.toString(): order.toJson(),
      payer.runtimeType.toString(): payer.toJson(),
      "applePayMerchantId": applePayMerchantId,
    };

    startApplePay(params).listen((event) {
      Log(event);
      MontyApplePayResult(event).triggerCallbacks(callback);
    });

    Log("[MontypaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}