
import 'dart:convert';

import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';
import 'package:montypay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';
import 'package:montypay_sdk/src/cardpay/MontyCardPayResult.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyCardPayAdapter extends BaseAdapter{

  execute({
    required MontypaySaleOrder order,
    required MontypayPayer payer,
    required CardPayResponseCallback? callback,
    Function(dynamic)? onFailure,
  }) {
    final params = {
      order.runtimeType.toString(): order.toJson(),
      payer.runtimeType.toString(): payer.toJson(),
    };

    startCardPay(params).listen((event) {
      Log(event);
      MontyCardPayResult(event).triggerCallbacks(callback);
    });

    Log("[MontypaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
