import 'package:montypay_sdk/src/adapters/MontyApplePayAdapter.dart';
import 'package:montypay_sdk/src/adapters/MontyCardPayAdapter.dart';
import 'package:montypay_sdk/src/adapters/MontyPayGetTransactionDetailsAdapter.dart';
import 'package:montypay_sdk/src/adapters/MontyPayGetTransactionStatusAdapter.dart';

import 'MontyPayCaptureAdapter.dart';
import 'MontyPayCreditVoidAdapter.dart';
import 'MontyPayRecurringSaleAdapter.dart';
import 'MontyPaySaleAdapter.dart';

class MontyPayAdapters{
  final CARD_PAY = MontyCardPayAdapter();
  final APPLE_PAY = MontyApplePayAdapter();

  final SALE = MontyPaySaleAdapter();
  final RECURRING_SALE = MontyPayRecurringSaleAdapter();
  final CAPTURE = MontyPayCaptureAdapter();
  final CREDIT_VOID = MontyPayCreditVoidAdapter();
  final TRANSACTION_STATUS = MontyPayGetTransactionStatusAdapter();
  final TRANSACTION_DETAILS = MontyPayGetTransactionDetailsAdapter();

}