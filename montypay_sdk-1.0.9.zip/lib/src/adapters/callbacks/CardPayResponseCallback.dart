
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class CardPayResponseCallback extends BaseResponseCallback{
  final Function(MontypayTransactionDetailsSuccess result) success;
  final Function(MontypayTransactionDetailsSuccess result) failure;

  CardPayResponseCallback({
    required this.success,
    required this.failure,
    required super.error
  });
}