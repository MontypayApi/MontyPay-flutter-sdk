
import 'package:montypay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';
import 'package:montypay_sdk/src/response/gettransactionstatus/MontypayTransactionStatusSuccess.dart';

class TransactionStatusResponseCallback extends BaseResponseCallback{
  final Function(MontypayTransactionStatusSuccess result) success;

  TransactionStatusResponseCallback({
    required this.success,
    required super.error
  });
}