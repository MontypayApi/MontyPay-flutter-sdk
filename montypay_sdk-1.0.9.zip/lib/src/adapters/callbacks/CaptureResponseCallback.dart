
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class CaptureResponseCallback extends BaseResponseCallback{
  final Function(MontypayCaptureSuccess result) success;
  final Function(MontypayCaptureDecline result) decline;

  CaptureResponseCallback({
    required this.success,
    required this.decline,
    required super.error
  });
}