
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';
import 'package:montypay_sdk/src/response/gettransactiondetails/MontypayTransactionDetailsSuccess.dart';

class TransactionDetailsResponseCallback extends BaseResponseCallback{
  final Function(MontypayTransactionDetailsSuccess result) success;

  TransactionDetailsResponseCallback({
    required this.success,
    required super.error
  });
}