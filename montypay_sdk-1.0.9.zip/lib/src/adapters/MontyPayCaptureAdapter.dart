
import 'dart:convert';

import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/src/adapters/BaseAdapter.dart';
import 'package:montypay_sdk/src/Helpers.dart';

class MontyPayCaptureAdapter extends BaseAdapter{

  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required double? amount,
    required CaptureResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }){

    final params = {
      "transactionId" : transactionId,
      "payerEmail" : payerEmail,
      "cardNumber" : cardNumber,
      "amount" : amount,
    };

    startCapture(params).listen((event) {
      Log(event);
      MontypayCaptureResult(event).triggerCallbacks(onResponse, onResponseJSON: onResponseJSON, );
    });

    Log("[MontypayCaptureAdapter.execute][Params] ${jsonEncode(params)}");
  }
}