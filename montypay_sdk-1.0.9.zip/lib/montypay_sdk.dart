library intl;

import 'package:montypay_sdk/src/Helpers.dart';
import 'package:montypay_sdk/src/adapters/MontyPayAdapters.dart';

import 'montypay_sdk_platform_interface.dart';

import 'dart:async';

export 'src/adapters/MontyPayAdapters.dart';
export 'src/adapters/callbacks/SaleResponseCallback.dart';
export 'src/adapters/callbacks/RecurringSaleResponseCallback.dart';
export 'src/adapters/callbacks/CaptureResponseCallback.dart';
export 'src/adapters/callbacks/CreditVoidResponseCallback.dart';
export 'src/adapters/callbacks/TransactionStatusResponseCallback.dart';
export 'src/adapters/callbacks/TransactionDetailsResponseCallback.dart';

export 'src/request/MontypayCard.dart';
export 'src/request/MontypayTestCards.dart';
export 'src/request/MontypayOrder.dart';
export 'src/request/MontypayPayer.dart';
export 'src/request/MontypayPayerOption.dart';
export 'src/request/MontypayRecurringOptions.dart';
export 'src/request/MontypaySaleOptions.dart';
export 'src/request/MontypaySaleOrder.dart';


export 'src/response/base/result/IDetailsMontypayResult.dart';
export 'src/response/base/result/IMontypayResult.dart';
export 'src/response/base/result/IOrderMontypayResult.dart';


export 'src/response/base/error/MontypayError.dart';
export 'src/response/base/error/MontypayExactError.dart';


export 'src/response/capture/MontypayCaptureSuccess.dart';
export 'src/response/capture/MontypayCaptureDecline.dart';
export 'src/response/capture/MontypayCaptureResult.dart';


export 'src/response/creditvoid/MontypayCreditvoidSuccess.dart';
export 'src/response/creditvoid/MontypayCreditVoidResult.dart';


export 'src/response/gettransactiondetails/MontypayTransaction.dart';
export 'src/response/gettransactiondetails/MontypayTransactionDetailsSuccess.dart';
export 'src/response/gettransactiondetails/MontypayTransactionDetailResult.dart';

export 'src/response/gettransactionstatus/MontypayTransactionStatusSuccess.dart';
export 'src/response/gettransactionstatus/MontypayTransactionStatusResult.dart';


export 'src/response/sale/MontypayRedirectParams.dart';
export 'src/response/sale/MontypaySale3DS.dart';
export 'src/response/sale/MontypaySale3dsRedirectParams.dart';
export 'src/response/sale/MontypaySaleDecline.dart';
export 'src/response/sale/MontypaySaleRecurring.dart';
export 'src/response/sale/MontypaySaleRedirect.dart';
export 'src/response/sale/MontypaySaleSuccess.dart';
export 'src/response/sale/MontypaySaleResult.dart';

export 'src/cardpay/MontyCardPay.dart';
export 'src/applepay/MontyApplePay.dart';


export 'src/api/MontypayAction.dart';
export 'src/api/MontypayStatus.dart';
export 'src/api/MontypayResult.dart';




class MontypaySdk {
  static final MontypaySdk _instance = MontypaySdk();
  static MontypaySdk get instance => _instance;

  Future<String?> getPlatformVersion() {
    return MontypaySdkPlatform.instance.getPlatformVersion();
  }

  Future<bool> config({required String key, required String password, bool enableDebug = false}){
    return MontypaySdkPlatform.instance.config(key, password, enableDebug);
  }


  MontyPayAdapters ADAPTER = MontyPayAdapters();
  Helpers HELPER = Helpers();
}
