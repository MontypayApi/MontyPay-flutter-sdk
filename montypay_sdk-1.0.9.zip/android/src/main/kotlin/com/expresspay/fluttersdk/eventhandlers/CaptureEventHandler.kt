package com.montypay.fluttersdk.eventhandlers

import com.montypay.sdk.core.MontypaySdk
import com.montypay.fluttersdk.helper.toMap
import com.montypay.sdk.model.request.card.MontypayCard
import com.montypay.sdk.model.request.options.MontypayRecurringOptions
import com.montypay.sdk.model.request.options.MontypaySaleOptions
import com.montypay.sdk.model.request.order.MontypayOrder
import com.montypay.sdk.model.request.order.MontypaySaleOrder
import com.montypay.sdk.model.request.payer.MontypayPayer
import com.montypay.sdk.model.response.base.MontypayResponse
import com.montypay.sdk.model.response.base.error.MontypayError
import com.montypay.sdk.model.response.capture.MontypayCaptureCallback
import com.montypay.sdk.model.response.capture.MontypayCaptureResponse
import com.montypay.sdk.model.response.capture.MontypayCaptureResult
import com.montypay.sdk.model.response.capture.MontypayCaptureSuccess
import com.montypay.sdk.model.response.sale.*
import com.google.gson.Gson
import io.flutter.plugin.common.EventChannel
import kotlin.math.sin


class CaptureEventHandler: EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            print(
                with(it) {
                    (get("transactionId") as? String)?.let { txnId ->
                        (get("payerEmail") as? String)?.let { payerEmail ->
                            (get("cardNumber") as? String)?.let { cardNumber ->
                                val amount = (get("amount") as? Double)
                                capture(payerEmail = payerEmail, cardNumber = cardNumber, transactionId = txnId, amount = amount)

                                "All params are valid"
                            } ?: "Missing 'cardNumber' parameter"
                        } ?: "Missing 'MontypayPayer' parameter"
                    } ?: "Missing 'transactionId' parameter"
                }
            )
        }

    }

    override fun onCancel(arguments: Any?) {
    }

    fun capture(payerEmail:String, cardNumber:String, transactionId:String, amount:Double?){
        MontypaySdk.Adapter.CAPTURE.execute(
            payerEmail = payerEmail,
            cardNumber = cardNumber,
            transactionId = transactionId,
            amount = amount,
            callback = object : MontypayCaptureCallback {
                override fun onResponse(response: MontypayCaptureResponse) {
                    send(mapOf("responseJSON" to response.toMap()))
                    super.onResponse(response)
                }

                override fun onResult(result: MontypayCaptureResult) {
                    val res = result.result
                    when (res) {
                        is MontypayCaptureSuccess -> send(mapOf("decline" to res.toMap()))
                        is MontypaySaleDecline -> send(mapOf("success" to res.toMap()))
                    }
                }

                override fun onError(error: MontypayError){
                    send(mapOf("error" to error.toMap()))
                }

                override fun onFailure(throwable: Throwable) {
                    send(mapOf("failure" to throwable.toMap()))
                    super.onFailure(throwable)
                }
            }
        )

    }

    private fun send(map:Map<*,*>){
        sink?.success(map)
    }
}