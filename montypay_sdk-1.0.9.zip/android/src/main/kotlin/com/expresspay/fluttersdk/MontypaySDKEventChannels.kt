package com.montypay.fluttersdk

import android.content.Context
import com.montypay.fluttersdk.eventhandlers.*
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel

/** MontypaySdkPlugin */
class MontypaySDKEventChannels{

  var cardpay:EventChannel? = null;
  var applepay:EventChannel? = null;

  var sale:EventChannel? = null;
  var recurringSale:EventChannel? = null;
  var capture:EventChannel? = null;
  var creditVoid:EventChannel? = null;
  var transactionStatus:EventChannel? = null;
  var transactionDetail:EventChannel? = null;
  var transactionLogs:EventChannel? = null;


  public fun initiate(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding, context: Context) {
    val messenger = flutterPluginBinding.binaryMessenger

    cardpay = EventChannel(messenger,"com.montypay.sdk.cardpay")
    sale = EventChannel(messenger,"com.montypay.sdk.sale")
    recurringSale = EventChannel(messenger,"com.montypay.sdk.recurringsale")
    capture = EventChannel(messenger,"com.montypay.sdk.capture")
    creditVoid = EventChannel(messenger,"com.montypay.sdk.creditvoid")
    transactionStatus = EventChannel(messenger,"com.montypay.sdk.transactionstatus")
    transactionDetail = EventChannel(messenger,"com.montypay.sdk.transactiondetail")
    transactionLogs = EventChannel(messenger,"com.montypay.sdk.transactionlogs")

    sale?.setStreamHandler(SaleEventHandler())
    recurringSale?.setStreamHandler(RecurringSaleEventHandler())
    capture?.setStreamHandler(CaptureEventHandler())
    creditVoid?.setStreamHandler(CreditVoidEventHandler())
    transactionStatus?.setStreamHandler(GetTransactionStatusEventHandler())
    transactionDetail?.setStreamHandler(GetTransactionDetailsEventHandler())
    cardpay?.setStreamHandler(CardPayEventHandler(context))

  }
}
