package com.montypay.fluttersdk.eventhandlers

import com.montypay.sdk.core.MontypaySdk
import com.montypay.fluttersdk.helper.toMap
import com.montypay.sdk.model.response.base.error.MontypayError
import com.montypay.sdk.model.response.creditvoid.MontypayCreditvoidResult
import com.montypay.sdk.model.response.creditvoid.MontypayCreditvoidSuccess
import com.montypay.sdk.model.response.gettransactiondetails.MontypayGetTransactionDetailsCallback
import com.montypay.sdk.model.response.gettransactiondetails.MontypayGetTransactionDetailsResponse
import com.montypay.sdk.model.response.gettransactiondetails.MontypayGetTransactionDetailsResult
import com.montypay.sdk.model.response.gettransactiondetails.MontypayGetTransactionDetailsSuccess
import com.montypay.sdk.model.response.sale.*
import io.flutter.plugin.common.EventChannel


class GetTransactionDetailsEventHandler: EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            print(
                with(it) {
                    (get("transactionId") as? String)?.let { txnId ->
                        (get("payerEmail") as? String)?.let { payerEmail ->
                            (get("cardNumber") as? String)?.let { cardNumber ->

                                txnDetails(payerEmail = payerEmail, cardNumber = cardNumber, transactionId = txnId)

                                "All params are valid"
                            } ?: "Missing 'cardNumber' parameter"
                        } ?: "Missing 'MontypayPayer' parameter"
                    } ?: "Missing 'transactionId' parameter"
                }
            )
        }

    }

    override fun onCancel(arguments: Any?) {
    }

    fun txnDetails(payerEmail:String, cardNumber:String, transactionId:String){
        MontypaySdk.Adapter.GET_TRANSACTION_DETAILS.execute(
            payerEmail = payerEmail,
            cardNumber = cardNumber,
            transactionId = transactionId,
            callback = object : MontypayGetTransactionDetailsCallback {
                override fun onResponse(response: MontypayGetTransactionDetailsResponse) {
                    send(mapOf("responseJSON" to response.toMap()))
                    super.onResponse(response)
                }

                override fun onResult(result: MontypayGetTransactionDetailsResult) {
                    val res = result.result
                    when (res) {
                        is MontypayGetTransactionDetailsSuccess -> send(mapOf("success" to res.toMap()))
                    }
                }

                override fun onError(error: MontypayError){
                    send(mapOf("error" to error.toMap()))
                }

                override fun onFailure(throwable: Throwable) {
                    send(mapOf("failure" to throwable.toMap()))
                    super.onFailure(throwable)
                }
            }
        )

    }

    private fun send(map:Map<*,*>){
        sink?.success(map)
    }
}