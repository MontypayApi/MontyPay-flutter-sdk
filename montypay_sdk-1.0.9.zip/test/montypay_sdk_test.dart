import 'package:flutter_test/flutter_test.dart';
import 'package:montypay_sdk/montypay_sdk.dart';
import 'package:montypay_sdk/montypay_sdk_platform_interface.dart';
import 'package:montypay_sdk/montypay_sdk_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockMontypaySdkPlatform
    with MockPlatformInterfaceMixin
    implements MontypaySdkPlatform {

  @override
  Future<String?> getPlatformVersion() => Future.value('42');

  @override
  Future<bool> config(String key, String password, bool enableDebug) {
    throw UnimplementedError();
  }
}

void main() {
  final MontypaySdkPlatform initialPlatform = MontypaySdkPlatform.instance;

  test('$MethodChannelMontypaySdk is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelMontypaySdk>());
  });

  test('getPlatformVersion', () async {
    MontypaySdk montypaySdkPlugin = MontypaySdk();
    MockMontypaySdkPlatform fakePlatform = MockMontypaySdkPlatform();
    MontypaySdkPlatform.instance = fakePlatform;

    expect(await montypaySdkPlugin.getPlatformVersion(), '42');
  });
}
