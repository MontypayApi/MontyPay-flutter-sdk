//
//  MontyPaySDKEventChannels.swift
//  montypay_sdk
//
//  Created by Zohaib Kambrani on 02/03/2023.
//

import Foundation
import Flutter
import UIKit
import MontyPaySDK


public class MontypaySdkMethodChannels: NSObject{
    var montyPaySdk:FlutterMethodChannel? = nil;

    final let methodGetPlatformVersion = "getPlatformVersion";
    final let methodConfig = "config";

    public func initiate(with flutterViewController: FlutterViewController){
        
        let messenger = flutterViewController.binaryMessenger
        
        montyPaySdk = FlutterMethodChannel(name: "com.montypay.sdk", binaryMessenger: messenger)
    }
    
}

