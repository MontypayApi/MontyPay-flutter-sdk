//
//  MontyPaySDK.h
//  MontyPaySDK
//
//  Created by Zohaib Kambrani on 26/01/2023.
// To Archive the Framework (xcodebuild archive)
// To Clean/Build/Arvice the Framework  (xcodebuild -project MontyPaySDK.xcodeproj -scheme MontyPaySDK -configuration Release CONFIGURATION_BUILD_DIR=. clean build)


/*
// Could not find module 'MontyPaySDK' for target 'arm64-apple-ios-simulator'; found: arm64-apple-ios, at: /Volumes/EdfaPay/Codes/Github/MontyPay/iOS/montypay-ios-sdk-framework/MontyPaySDK.framework/Modules/MontyPaySDK.swiftmodule


// Archive Framework for Simulator
xcodebuild archive \
-scheme MontyPaySDK \
-configuration Release \
-destination 'generic/platform=iOS Simulator' \
-archivePath './build/MontyPaySDK.framework-iphonesimulator.xcarchive' \
SKIP_INSTALL=NO \
BUILD_LIBRARIES_FOR_DISTRIBUTION=YES


// Archive Framework for iOS
xcodebuild archive \
-scheme MontyPaySDK \
-configuration Release \
-destination 'generic/platform=iOS' \
-archivePath './build/MontyPaySDK.framework-iphoneos.xcarchive' \
SKIP_INSTALL=NO \
BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

*/

#import <Foundation/Foundation.h>

//! Project version number for MontyPaySDK.
FOUNDATION_EXPORT double MontyPaySDKVersionNumber = 2;

//! Project version string for MontyPaySDK.
FOUNDATION_EXPORT const unsigned char MontyPaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like


